import { motion } from "motion/react";

const testimonials = [
  {
    quote: "AgentAuth let us ship autonomous purchasing in our app without worrying about fraud or compliance. Game changer.",
    author: "Sarah Chen",
    role: "CTO, ShopBot AI",
    avatar: "SC",
  },
  {
    quote: "The API is incredibly simple. We integrated it in an afternoon and our agents were making purchases by end of day.",
    author: "Marcus Johnson",
    role: "Engineering Lead, AutoAssist",
    avatar: "MJ",
  },
  {
    quote: "Finally, a payment solution built for the AI era. Spending controls give our users the confidence to let agents transact freely.",
    author: "Elena Rodriguez",
    role: "Founder, AgentMarket",
    avatar: "ER",
  },
];

export function Testimonials() {
  return (
    <section className="relative px-6 py-24 border-t border-white/5">
      <div className="max-w-6xl mx-auto">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-4xl mb-4 text-white">Trusted by AI Builders</h2>
          <p className="text-xl text-gray-400">
            Join teams building the next generation of autonomous commerce
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-6">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              whileHover={{ 
                y: -10,
                rotateY: 5,
                transition: { duration: 0.3 }
              }}
              style={{ transformStyle: 'preserve-3d' }}
            >
              <motion.div 
                className="relative p-8 rounded-xl border border-white/5 bg-white/[0.02] h-full overflow-hidden group"
                whileHover="hover"
              >
                {/* Glow effect on hover */}
                <motion.div
                  className="absolute inset-0 bg-gradient-to-br from-white/10 via-transparent to-transparent opacity-0"
                  variants={{
                    hover: { opacity: 1 }
                  }}
                  transition={{ duration: 0.3 }}
                />

                <div className="relative">
                  <motion.div 
                    className="mb-6"
                    whileHover={{ rotate: 180, transition: { duration: 0.5 } }}
                  >
                    <svg className="w-8 h-8 text-white/20" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M14.017 21v-7.391c0-5.704 3.731-9.57 8.983-10.609l.995 2.151c-2.432.917-3.995 3.638-3.995 5.849h4v10h-9.983zm-14.017 0v-7.391c0-5.704 3.748-9.57 9-10.609l.996 2.151c-2.433.917-3.996 3.638-3.996 5.849h3.983v10h-9.983z" />
                    </svg>
                  </motion.div>
                  <p className="text-gray-300 mb-6 leading-relaxed">
                    "{testimonial.quote}"
                  </p>
                  <div className="flex items-center gap-3">
                    <motion.div 
                      className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center text-sm text-white"
                      whileHover={{ 
                        scale: 1.2,
                        rotate: 10,
                        transition: { duration: 0.3 }
                      }}
                    >
                      {testimonial.avatar}
                    </motion.div>
                    <div>
                      <div className="text-white">{testimonial.author}</div>
                      <div className="text-sm text-gray-400">{testimonial.role}</div>
                    </div>
                  </div>
                </div>

                {/* Corner glow */}
                <motion.div
                  className="absolute bottom-0 right-0 w-24 h-24 bg-white/5 blur-2xl"
                  initial={{ opacity: 0 }}
                  variants={{
                    hover: { opacity: 1 }
                  }}
                />
              </motion.div>
            </motion.div>
          ))}
        </div>

        {/* Final CTA */}
        <motion.div 
          className="mt-24 text-center p-12 rounded-2xl border border-white/10 bg-gradient-to-b from-white/[0.05] to-transparent overflow-hidden relative"
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          style={{ transformStyle: 'preserve-3d' }}
          whileHover={{ 
            scale: 1.02,
            transition: { duration: 0.3 }
          }}
        >
          {/* Animated gradient background */}
          <motion.div
            className="absolute inset-0 bg-gradient-to-br from-white/10 via-transparent to-transparent"
            animate={{
              opacity: [0.3, 0.6, 0.3],
            }}
            transition={{
              duration: 3,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          />

          <div className="relative">
            <h2 className="text-3xl mb-4 text-white">Ready to Get Started?</h2>
            <p className="text-xl text-gray-400 mb-8 max-w-2xl mx-auto">
              Join the waitlist and be among the first to give your AI agents the power to transact safely.
            </p>
            <motion.button
              onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
              className="px-8 py-4 bg-white hover:bg-gray-200 text-black rounded-lg transition-all inline-flex items-center gap-2"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              Join the Waitlist
              <motion.svg 
                className="w-5 h-5" 
                fill="none" 
                viewBox="0 0 24 24" 
                stroke="currentColor"
                animate={{ x: [0, 5, 0] }}
                transition={{ duration: 1.5, repeat: Infinity }}
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
              </motion.svg>
            </motion.button>
          </div>
        </motion.div>
      </div>
    </section>
  );
}