import { Hero } from "./components/Hero";
import { Features } from "./components/Features";
import { UseCases } from "./components/UseCases";
import { HowItWorks } from "./components/HowItWorks";
import { Testimonials } from "./components/Testimonials";
import { FAQ } from "./components/FAQ";
import { LaunchSection } from "./components/LaunchSection";

export default function App() {
  return (
    <div className="dark min-h-screen bg-[#0A0A0F] text-foreground">
      <div className="relative">
        {/* Gradient background effects */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[800px] bg-white/5 rounded-full blur-[120px]" />
          <div className="absolute top-1/3 right-0 w-[600px] h-[600px] bg-white/3 rounded-full blur-[100px]" />
        </div>

        {/* Content */}
        <div className="relative">
          <Hero />
          <Features />
          <UseCases />
          <HowItWorks />
          <Testimonials />
          <FAQ />
          <LaunchSection />
        </div>
      </div>
    </div>
  );
}